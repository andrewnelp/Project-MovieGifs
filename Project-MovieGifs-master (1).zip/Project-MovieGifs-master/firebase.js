var app_fireBase = {};
(function(){
    // Initialize Firebase  
    var config = {
        apiKey: "AIzaSyC1R2VMtgkj8c9VlbP7F5aZFwkBmpX-Yt8",
        authDomain: "bootcamp-78721.firebaseapp.com",
        databaseURL: "https://bootcamp-78721.firebaseio.com",
        projectId: "bootcamp-78721",
        storageBucket: "bootcamp-78721.appspot.com",
        messagingSenderId: "601185461394"
      };
      firebase.initializeApp(config);

      app_fireBase = firebase;
 


      
})();

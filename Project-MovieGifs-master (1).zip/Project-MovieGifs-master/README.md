This is a website created to entertain and provide some usefulel information for movie lovers

All the information in this presentation https://docs.google.com/presentation/d/14SG21ASauKSJq3chML1KYkgLKxxs_Y7n8D7WcYK2Qoc/edit?usp=sharing